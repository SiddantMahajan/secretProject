﻿namespace VideoChat.Models
{
    public class User
    {
        public string Username;
        public string ConnectionId;
        public bool InCall;
    }
}